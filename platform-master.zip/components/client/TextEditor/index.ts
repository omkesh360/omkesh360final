export type { Editor, Extensions, JSONContent } from '@tiptap/core';

export * from './TextEditor';
